
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <?php echo $__env->make('admin.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card">
            <div class="card-body">
            <div class="row">
                <div class="col-5 align-self-center">
                    <h4 class="page-title">All Payment Method </h4>
                </div>
                <div class="col-7 align-self-center mb-2">
                    <div class="d-flex no-block justify-content-end align-items-center">
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#paymentPethodAddModal" data-whatever="@mdo">Add Payment Method</button>
                    </div>
                </div>
            </div>
                <div class="table-responsive">
                    <table class="table" id="paymentMethodTable">
                        <thead>
                            <tr>
                                <th scope="col">S.I</th>
                                <th scope="col">Method Name</th>
                                <th scope="col">Description</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $payment_methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment_method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->index+1); ?></td>
                                <td><?php echo e($payment_method->method_name); ?></td>
                                <td><?php echo e($payment_method->description); ?></td>
                                <td>
                                    <a href="/" data-toggle="modal" data-target="#paymentMethodEditModal" onclick="risePaymentMethodEditModal('<?php echo e($payment_method->method_name); ?>','<?php echo e($payment_method->description); ?>','<?php echo e($payment_method->id); ?>')"><i class="font-18 far fa-edit text-info"></i></a>
                                    <a href="<?php echo e(route('product.payment-method.destroy',['payment_method_id' => $payment_method->id])); ?>"><i class="font-18 far fa-trash-alt text-danger"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-danger text-center" colspan="3">This table data is empty</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('admin.pages.products.payment-method.modals.add-payment-method', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.pages.products.payment-method.modals.edit-payment-method', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom_styles'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom_scripts'); ?>
<script>
    $('#paymentMethodTable').DataTable();
    function risePaymentMethodEditModal(method_name,description,id){
      $('#hiddenPaymentMethodId').val(id);
       $('#paymentMethodEditModal input[name="method_name"]').val(method_name);
       $('#paymentMethodEditModal textarea[name="description"]').val(description);
    }
 </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tms-master\resources\views/admin/pages/products/payment-method/list.blade.php ENDPATH**/ ?>