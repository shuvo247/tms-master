
<?php $__env->startSection('content'); ?>
<div class="col-12">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Add Product</h4>
            <div class="repeater-default m-t-30">
                <div data-repeater-list="">
                    <div data-repeater-item="">
                        <form action="<?php echo e(route('product.product.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-row">
                                <div class="form-group col-md-3">
                                    <label for="supplierName">Select Supplier <span class="text-danger">*</span></label>
                                    <select class="form-control select-2" id="supplierName" name="supplier_id" required multiple>
                                        <?php $__currentLoopData = App\Models\Supplier::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($supplier->id); ?>"><?php echo e($supplier->supplier_name); ?> | <?php echo e($supplier->organization_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="productCategory">Category <span class="text-danger">*</span></label>
                                    <select class="form-control select-2" id="productCategory" name="category_id" multiple>
                                        <?php $__currentLoopData = App\Models\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="productBrand">Brand <span class="text-danger">*</span></label>
                                    <select class="form-control select-2" id="productBrand" name="brand_id">
                                        <?php $__currentLoopData = App\Models\Brand::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->brand_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="paymentMethod">Payment Method <span class="text-danger">*</span></label>
                                    <select class="form-control select-2" id="paymentMethod" name="payment_method_id" required>
                                        <?php $__currentLoopData = App\Models\PaymentMethod::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment_method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($payment_method->id); ?>"><?php echo e($payment_method->method_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-3">
                                    <label for="productName">Product Name <span class="text-danger">*</span></label>
                                    <input name="product_name" type="text" class="form-control" id="productName" placeholder="Ex : A 02">
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="productPcsPerBox">Pcs Per Box <span class="text-danger">*</span></label>
                                    <input name="pcs_per_box" type="number" class="form-control" id="productPcsPerBox" placeholder="Ex : 25">
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="alertQuantity">Alert Quantity <span class="text-danger">*</span></label>
                                    <input name="alert_quantity" type="number" class="form-control" id="alertQuantity" placeholder="Ex : 400">
                                </div>
                                <!-- <div class="form-group col-md-3">
                                    <label for="alertQuantity">Image</label>
                                        <input type="file" name="image">
                                    </div> -->
                                <div class="form-group col-md-3">
                                    <label for="pwd">Product Type</label>
                                    <select name="product_type" class="form-control" id="getProductType"
                                        onchange="getProductTypeChoose()">
                                        <option value="single" selected>Single</option>
                                        <option value="variable">Variable</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div  id="singleProduct">
                                <div class="form-row">
                                    <div class="form-group col-md-3">
                                        <label for="productPurchasePrice">Purchase Price</label>
                                        <input name="purchase_price" type="number" class="form-control" id="productPurchasePrice" placeholder="Ex : 35">
                                    </div>
                                    <div class="form-group col-md-3">
                                        <label for="productSellPrice">Sell Price</label>
                                        <input name="sell_price" type="number" class="form-control" id="productSellPrice" placeholder="Ex : 38">
                                    </div>
                                    <div class="form-group col-md-3">
                                        <label for="quantity">Quantity(sft)</label>
                                        <input name="qty_in_sft" type="number" class="form-control" id="quantity" placeholder="Ex : 1200">
                                    </div>
                                </div>
                            </div>
                            <div id="variableProduct">
                                    <div class="row">
                                        <div class="col-12">
                                            <?php
                                                $getSizeAttributeId = App\Models\ProductAttribute::where('attribute_name','Size')->first();
                                                $getGradeAttributeId = App\Models\ProductAttribute::where('attribute_name','Grade')->first();
                                            ?>
                                            <div class="row">
                                                <div class="form-group col-md-2">
                                                <label for="attributeName" class="col-form-label">Select Product Size</label>
                                                    <div id="inputFormRow">
                                                        <select class="form-control select-2"  name="size_attribute_id[]">
                                                            <?php $__currentLoopData = App\Models\AttributeValue::where('attribute_id',$getSizeAttributeId->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($value->id); ?>"><?php echo e($value->attribute_value); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <label for="attributeName" class="col-form-label">Select Product Grade</label>
                                                     <div id="inputFormRow">
                                                        <select class="form-control select-2" name="grade_attribute_id[]">
                                                            <?php $__currentLoopData = App\Models\AttributeValue::where('attribute_id',$getGradeAttributeId->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($value->id); ?>"><?php echo e($value->attribute_value); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div id="inputFormRow">
                                                    <label for="attributeName" class="col-form-label">Purchase Price</label>
                                                        <div class="input-group mb-3">
                                                            <input type="text" name="variant_purchase_price[]" class="form-control m-input" placeholder="Enter Value" autocomplete="off">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div id="inputFormRow">
                                                    <label for="attributeName" class="col-form-label">Sell Price</label>
                                                        <div class="input-group mb-3">
                                                            <input type="text" name="variant_sell_price[]" class="form-control m-input" placeholder="Enter Value" autocomplete="off">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div id="inputFormRow">
                                                    <label for="attributeName" class="col-form-label">Quantity (sft)</label>
                                                        <div class="input-group mb-3">
                                                            <input type="text" name="quantity[]" class="form-control m-input" placeholder="Enter Value" autocomplete="off">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <label for="attributeName" class="col-form-label">Add Row</label>
                                                    <div class="ml-auto">
                                                        <button id="addRow" type="button" class="btn btn-info">Add Row</button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div id="newRow" class="row">
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <div class="form-group col-md-12">
                                <button class="btn btn-success waves-effect waves-light" type="submit">Submit
                                </button>
                                <button data-repeater-delete="" class="btn btn-danger waves-effect waves-light m-l-10" type="button">Reset
                                </button>
                            </div>
                        </form>
                        <hr>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/tms-master/resources/views/admin/pages/products/products/add-product.blade.php ENDPATH**/ ?>