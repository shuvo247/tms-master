
<?php $__env->startSection('custom_styles'); ?>
<link href="<?php echo e(asset('backend/assets/css/select-2.css')); ?>" rel="stylesheet" />
<style>
    .select2-container{
        width: 100% !important;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
     <?php echo $__env->make('admin.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card">
            <div class="card-body">
            <div class="row">
                <div class="col-5 align-self-center">
                    <h4 class="page-title">All Product </h4>
                </div>
                <div class="col-7 align-self-center mb-2">
                    <div class="d-flex no-block justify-content-end align-items-center">
                        <a href="<?php echo e(route('product.product.add')); ?>" class="btn btn-primary" data-whatever="@mdo">Add Product</a>
                    </div>
                </div>
            </div>
                <div class="table-responsive">
                    <table class="table" id="productTable">
                        <thead>
                            <tr>
                                <th scope="col">S.I</th>
                                <th scope="col">Category Name</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
    $getSizeAttributeId = App\Models\ProductAttribute::where('attribute_name','Size')->first();
    $getGradeAttributeId = App\Models\ProductAttribute::where('attribute_name','Grade')->first();
?>
<?php echo $__env->make('admin.pages.products.products.add-product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom_scripts'); ?>
<script src="<?php echo e(asset('backend/assets/js/select-2.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/js/custom/product.js')); ?>"></script>
<script>
    $('#singleProduct').css('display', 'block');
    $('#variableProduct').css('display', 'none');
    function getProductTypeChoose() {
        const producType = $("#getProductType").val();
        if (producType == 'single') {
            $('#singleProduct').css('display', 'block');
            $('#variableProduct').css('display', 'none');
        } else {
            $('#singleProduct').css('display', 'none');
            $('#variableProduct').css('display', 'block');
        }
    }
   $("#addRow").click(function () {
       var html = '';
       html += '<div class="recentRow col-12 row" style="margin:0;padding:0">';
       html += ' <div class="form-group col-md-2">';
       html += '<div id="inputFormRow">';
       html += '<div class="input-group mb-3">';
       html += '<select class="form-control select-2" name="size_attribute_id[]">';
       html += '<?php $__currentLoopData = App\Models\AttributeValue::where('attribute_id',$getSizeAttributeId->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>';
       html += '<option value="<?php echo e($value->id); ?>"><?php echo e($value->attribute_value); ?></option>';
       html += '<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>';
       html += '</select>'
       html += '<div class="input-group-append">';
       html += '</div>';
       html += '</div>';
       html += '</div>';
       html += '</div>';
       html += ' <div class="form-group col-md-2">';
       html += '<div id="inputFormRow">';
       html += '<div class="input-group mb-3">';
       html += '<select class="form-control select-2" name="grade_attribute_id[]">';
       html += '<?php $__currentLoopData = App\Models\AttributeValue::where('attribute_id',$getGradeAttributeId->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>';
       html += '<option value="<?php echo e($value->id); ?>"><?php echo e($value->attribute_value); ?></option>';
       html += '<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>';
       html += '</select>'
       html += '<div class="input-group-append">';
       html += '</div>';
       html += '</div>';
       html += '</div>';
       html += '</div>';
       html += ' <div class="form-group col-md-2">';
       html += '<div id="inputFormRow">';
       html += '<div class="input-group mb-3">';
       html += '<input type="text" name="variant_purchase_price[]" class="form-control m-input" placeholder="Enter Value" autocomplete="off">';
       html += '<div class="input-group-append">';
       html += '</div>';
       html += '</div>';
       html += '</div>';
       html += '</div>';
       html += ' <div class="form-group col-md-2">';
       html += '<div id="inputFormRow">';
       html += '<div class="input-group mb-3">';
       html += '<input type="text" name="variant_sell_price[]" class="form-control m-input" placeholder="Enter Value" autocomplete="off">';
       html += '<div class="input-group-append">';
       html += '</div>';
       html += '</div>';
       html += '</div>';
       html += '</div>';
       html += ' <div class="form-group col-md-2">';
       html += '<div id="inputFormRow">';
       html += '<div class="input-group mb-3">';
       html += '<input type="text" name="quantity[]" class="form-control m-input" placeholder="Enter Value" autocomplete="off">';
       html += '<div class="input-group-append">';
       html += '</div>';
       html += '</div>';
       html += '</div>';
       html += '</div>';
       html += ' <div class="form-group col-md-2">';
       html += '<div id="inputFormRow">';
       html += '<button id="removeRow" type="button" class="btn btn-danger">Remove</button>';
       html += '</div>';
       html += '</div>';
       html += '</div>';
       html += '</div>';
       html += '</div>';
       html += '</div>';
       $('#newRow').append(html);
       $('.select-2').select2();
   });
 
   // remove row
   $(document).on('click', '#removeRow', function () {
       $(this).closest('.recentRow').remove();
   });
    // Select 2 and DataTable
    $('#productTable').DataTable();
    $('.select-2').select2();

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/tms-master/resources/views/admin/pages/products/products/list.blade.php ENDPATH**/ ?>