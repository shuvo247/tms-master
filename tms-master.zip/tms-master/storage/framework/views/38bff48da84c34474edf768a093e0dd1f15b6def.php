    <!-- Custom CSS -->
    <link href="<?php echo e(asset('backend/assets/libs/chartist/dist/chartist.min.css')); ?>" rel="stylesheet">
    <!-- <link href="<?php echo e(asset('backend/assets/extra-libs/c3/c3.min.css')); ?>" rel="stylesheet"> -->
    <!-- Custom CSS -->
    <link href="<?php echo e(asset('backend/assets/css/style.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" />
    <link href="<?php echo e(asset('backend/assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="http://localhost:8000/backend/assets/css/icons/material-design-iconic-font/css/materialdesignicons.min.css">
    <?php echo $__env->yieldContent('custom_styles'); ?><?php /**PATH /opt/lampp/htdocs/tms-master/resources/views/admin/partials/styles.blade.php ENDPATH**/ ?>