<footer class="footer text-center">
    Copyright ©️ 2021 All rights reserved
</footer><?php /**PATH C:\xampp\htdocs\tms-master\resources\views/admin/partials/footer.blade.php ENDPATH**/ ?>