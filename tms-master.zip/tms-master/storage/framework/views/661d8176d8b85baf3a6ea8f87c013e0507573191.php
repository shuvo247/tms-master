
<?php $__env->startSection('custom_styles'); ?>
<link href="<?php echo e(asset('backend/assets/css/select-2.css')); ?>" rel="stylesheet" />
<style>
    .select2-container{
        width: 100% !important;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <?php echo $__env->make('admin.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card">
            <div class="card-body">
            <div class="row">
                <div class="col-5 align-self-center">
                    <h4 class="page-title">All Product </h4>
                </div>
                <div class="col-7 align-self-center mb-2">
                    <div class="d-flex no-block justify-content-end align-items-center">
                        <a href="<?php echo e(route('product.product.add')); ?>" class="btn btn-primary" data-whatever="@mdo">Add Product</a>
                    </div>
                </div>
            </div>
                <div class="table-responsive">
                    <table class="table" id="productTable">
                        <thead>
                            <tr>
                                <th scope="col">S.I</th>
                                <th scope="col">Category Name</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('admin.pages.products.products.add-product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_scripts'); ?>
<script src="<?php echo e(asset('backend/assets/js/select-2.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/js/custom/product.js')); ?>"></script>
<script>
    // Get Attribute Value
    function 
    // Select 2 and DataTable
    $('#productTable').DataTable();
    $('.select-2').select2();

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tms-master\resources\views/admin/pages/products/products/list.blade.php ENDPATH**/ ?>