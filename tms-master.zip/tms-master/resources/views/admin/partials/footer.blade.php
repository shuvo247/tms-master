<footer class="footer text-center">
    Copyright ©️ 2021 All rights reserved
</footer>