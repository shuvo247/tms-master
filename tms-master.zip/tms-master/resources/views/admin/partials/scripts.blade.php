
<script src="{{asset('backend/assets/js/jquery.min.js')}}"></script>
<!-- Bootstrap tether Core JavaScript -->
<script src="{{asset('backend/assets/libs/popper.js/dist/umd/popper.min.js')}}"></script>
<script src="{{asset('backend/assets/libs/bootstrap/dist/js/bootstrap.min.js')}}"></script>
<!-- apps -->
<script src="{{asset('backend/assets/js/app.min.js')}}"></script>
<script src="{{asset('backend/assets/js/app.init.js')}}"></script>
<script src="{{asset('backend/assets/js/app.init.vertical.js')}}"></script>
<script src="{{asset('backend/assets/js/app-style-switcher.js')}}"></script>
<!-- slimscrollbar scrollbar JavaScript -->
<script src="{{asset('backend/assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js')}}"></script>
<script src="{{asset('backend/assets/extra-libs/sparkline/sparkline.js')}}"></script>
<!--Wave Effects -->
<script src="{{asset('backend/assets/js/waves.js')}}"></script>
<!--Menu sidebar -->
<script src="{{asset('backend/assets/js/sidebarmenu.js')}}"></script>
<!--Custom JavaScript -->
<script src="{{asset('backend/assets/js/custom.min.js')}}"></script>
<!--This page JavaScript -->
<!--chartis chart-->
<script src="{{asset('backend/assets/libs/chartist/dist/chartist.min.js')}}"></script>
<script src="{{asset('backend/assets/libs/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.min.js')}}"></script>
<!--c3 charts -->
<script src="{{asset('backend/assets/extra-libs/c3/d3.min.js')}}"></script>
<script src="{{asset('backend/assets/extra-libs/c3/c3.min.js')}}"></script>
<!--chartjs -->
<script src="{{asset('backend/assets/libs/chart.js/dist/Chart.min.js')}}"></script>
<script src="{{asset('backend/assets/js/pages/dashboards/dashboard-clasic.js')}}"></script>
<script src="{{asset('backend/assets/extra-libs/DataTables/datatables.min.js')}}"></script>>
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" integrity="sha512-RXf+QSDCUQs5uwRKaDoXt55jygZZm2V++WUZduaU/Ui/9EGp3f/2KZVahFZBKGH0s774sd3HmrhUy+SgOFQLVQ==" crossorigin="anonymous"></script>

@yield('custom_scripts')
